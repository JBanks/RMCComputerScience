Help to use Liang_IO with Eclipse:

The process to modify the build path for a project is laid out below:

 - zip the whole folder of Liang_IO, such as Liang_IO.zip (available in L:\Math\CSE350)

 - Select the project in eclipse

 - Project -> Properties (a new window will appear)

 - select "Java Build Path"

 - In the content pane, select the libraries tab

 - Add External JARs...

 - Browse to the location of the zip file (Liang_IO.zip), and select the file.

 - Click ok to save the changes in the properties window.

The .class files are now included as part of the build path, allowing them to be used.

The following code (Test.java) compiled and ran fine.

package workpackage;

import Liang_IO.*;

public class Test {

    public static void main(String args[]){
        int a = 0;
        a = KeyBoardReader.readInt("");
        System.out.println("a: " + a);
    }
}