/* Author:  your-name-here  */

#include <stdio.h>
#include "petri.h"

int main(void) {
	printf("Petri...\n");
}


