/* Author: your-name-here  */

#include <stdio.h>
#include <stdlib.h>

#include "petri.h"

void print_petri_dish(int dish[][EDGE_LENGTH]) {
	//yours... a vous
}

bool are_adjacent_infected(int dish[][EDGE_LENGTH], int row, int col) {
	// yours... a vous
	return false;
}

void spread_infection(int dish[][EDGE_LENGTH]) {
	// yours... a vous
}

