/* your name | votre nom  */

#include <stdio.h>
#include <stdlib.h>
#include "hull_damage.h"

int main(void) {
	int hull[EDGE_LENGTH][EDGE_LENGTH];
	char greys[EDGE_LENGTH][EDGE_LENGTH];
//	const int impacts[N_IMPACTS][2] = IMPACTS;

	initialize(hull);
	printf("initial hull status:\n");
	display_numeric(hull);

	return EXIT_SUCCESS;
}

