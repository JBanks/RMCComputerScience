/* your name | votre nom */

#include <stdio.h>
#include <stdbool.h>
#include "hull_damage.h"

void initialize(int hull[][EDGE_LENGTH]) {
	for (int row = 0; row < EDGE_LENGTH; row++) {
		for (int col = 0; col < EDGE_LENGTH; col++) {
			hull[row][col] = INITIAL_HULL_STRENGTH;
		}
	}
}

void display_numeric(int hull[][EDGE_LENGTH]) {
	for (int row = 0; row < EDGE_LENGTH; row++) {
		for (int col = 0; col < EDGE_LENGTH; col++) {
			printf("%-3d", hull[row][col]);
		}
		printf("\n");
	}
}

void display_characters(char greys[][EDGE_LENGTH]) {
	for (int row = 0; row < EDGE_LENGTH; row++) {
		for (int col = 0; col < EDGE_LENGTH; col++) {
			printf("%-2c", greys[row][col]);
		}
		printf("\n");
	}
}

void convert(int hull[][EDGE_LENGTH], char greys[][EDGE_LENGTH]) {
//	const char greyscale[] = GREYSCALE;

	// yours | a vous
}

void missile_impact(int hull[][EDGE_LENGTH], int missle_row, int missile_col) {
//	const int damage_grid[][3] = DAMAGE;

	// yours | a vous
}

bool breached(int hull[][EDGE_LENGTH]) {
	// yours | a vous
	return false;
}



