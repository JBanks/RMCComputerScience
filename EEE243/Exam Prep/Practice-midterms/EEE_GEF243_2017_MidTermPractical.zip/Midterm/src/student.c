/*
 * student.c
 *
 *  Created on: Oct 13, 2017
 *      Author: lapointe
 */
#include "student.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

float calculator(int choice, float a, float b) {
	// yours | a vous
	return 0.0;
}

double deg_to_rad(double deg) {
	// yours | a vous
	return 0.0;
}

double power(double x, double y) {
	// yours | a vous
	return 0.0;
}

double factorial(int x) {
	// yours | a vous
	return 0.0;
}

double sinus(double x, int n) {
	// yours | a vous
	return 0.0;
}

int *row_adder(int matrix[][WIDTH], int height) {
	// yours | a vous
	return NULL;
}

void convert_to_ascii(int image[][IMG_SIZE], char ascii[][IMG_SIZE]) {
	// yours | a vous
}

void display_image(char ascii[][IMG_SIZE]) {
	/* Your code here */
}
