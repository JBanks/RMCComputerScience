/* DO NOT MODIFY | NE MODIFIEZ PAS */

#ifndef SUPPORT_H_
#define SUPPORT_H_

// Question 1 support functions
float addition(float a, float b);
float difference(float a, float b);
float multiplication(float a, float b);
float division(float a, float b);
void interface_calc(int *choice, float *a, float *b);

// Question 3 support functions
void display_row_matrix(int *matrix, int size);

#endif /* SUPPORT_H_ */
