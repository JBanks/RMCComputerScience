/* your name | votre nom  */

#include <stdio.h>
#include <stdlib.h>

#include "student.h"
#include "sphere.h"

int main() {
	// Question 1
	printf("================== QUESTION 1 ==================\n");
	int choice;
	float a,b;
//	for (int i = 0; i < 4; i++) {
//		interface_calc(&choice, &a, &b);
//		printf("The result is %0.2f\n", calculator(choice, a, b));
//	}

	// Question 2
	printf("================== QUESTION 2 ==================\n");
//	printf("Sine of 90 is %0.3f\n",sinus(90, 4));
//	printf("Sine of 180 is %0.3f\n",sinus(180, 4));

	// Question 3
	printf("================== QUESTION 3 ==================\n");
//	int array[3][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
//	int *total = row_adder(array, 3);
//	display_row_matrix(total, 3);

	// Question 4
	printf("================== QUESTION 4 ==================\n");
//	char ascii[IMG_SIZE][IMG_SIZE];
//	convert_to_ascii(img, ascii);
//	display_image(ascii);

	return EXIT_SUCCESS;
}
