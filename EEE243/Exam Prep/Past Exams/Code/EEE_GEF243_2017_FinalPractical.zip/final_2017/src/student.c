/*
 *
 *	This file is where you implement the functions to solve the problems posed to
 *	you in the exam booklet.
 *
 *	Ce fichier est l'endroit ou vous implementez les fonctions pour resoudre les
 *	probleme qui vous sont poses dans l'examen
 *
 * Author/Auteur: YOUR NAME / VOTRE NOM
 * Col Num/No Col: YOUR COLLEGE NUMBER / VOTRE NUMERO DE COLLEGE
 *
 * Version: 30 Nov 2017
 *
 */
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "student.h"

/*
 * Function to implement for question 1.
 *
 * Fonction a implementer pour la question 1.
 *
 */
enum StdCol convert_col(unsigned char color[3]) {
	// yours | a vous
	return 0;
}

/*
 * Function to implement for question 2.
 *
 * Fonction a implementer pour la question 2.
 *
 */
struct Action *add_node(struct Action *new, struct Action *current) {
	struct Action *temp = NULL;
	if (current != NULL) {
		temp = current->next;
		current->next = new;
		new->prev = current;
	}
	if (temp != NULL) {
		delete_following_action(temp);
	}
	return new;
}

/*
 * Function to implement for question 2.
 *
 * Fonction a implementer pour la question 2.
 *
 */
void delete_following_action(struct Action *entry_point) {
	// yours | a vous
}

/*
 * Function to implement for question 2.
 *
 * Fonction a implementer pour la question 2.
 *
 */
struct Action *undo(struct Action *current) {
	// yours | a vous
	return current;
}

/*
 * Function to implement for question 2.
 *
 * Fonction a implementer pour la question 2.
 *
 */
struct Action *redo(struct Action *current) {
	// yours | a vous
	return current;
}

/*
 * Function to implement for question 3.
 *
 * Fonction a implementer pour la question 3.
 *
 */
unsigned int *generate_histogram(unsigned char image[IMG_SIZE][IMG_SIZE],
		unsigned char range) {
	// yours | a vous
	return NULL;
}

/*
 * Function to implement for question 4.
 *
 * Fonction a implementer pour la question 4.
 *
 */
void find_replace_str(char *str, char *replace, char *in, char *out) {
	// yours | a vous
}
