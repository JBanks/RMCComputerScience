/* YOUR NAME HERE | VOTRE NOM ICI */

#include <stdio.h>
#include <stdlib.h>

#include "sched.h"

int main() {
	Process *queues[3] = { NULL, NULL, NULL };
	print_column_headings();
	print_one_process(create_process());
	return EXIT_SUCCESS;
}

Process *add_in_order(Process *head, Process *new) {
	// to complete | a completer
	return head;
}

void print_queue(Process *head) {
	// to complete | a completer
}

void add_to_queues(Process **queues, Process *new) {
	// to complete | a completer
}

void print_all_queues(Process **queues) {
	// to complete | a completer
}

Process *remove_process(Process **head) {
	// to complete | a completer
	return NULL;
}

void schedule(Process **queues) {
	// to complete | a completer
}

float calculate_total_mem_GB(Process **queues) {
	// to complete | a completer
	return 0;
}
